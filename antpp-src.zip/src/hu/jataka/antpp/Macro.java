package hu.jataka.antpp;

public class Macro {
    String name;

    public void setName(String name) {
        this.name = name;
    }

    String value;

    public void setValue(String value) {
        this.value = value;
    }

    String ifExpression;

    public void setIf(String ifExpression) {
        this.ifExpression = ifExpression;
    }    
}
